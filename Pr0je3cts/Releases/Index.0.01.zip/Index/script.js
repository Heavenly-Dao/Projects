let files = JSON.parse(localStorage.getItem('files')) || [];

document.addEventListener('DOMContentLoaded', () => {
    displayFiles();
});

function importFile() {
    const fileInput = document.getElementById('file');
    const categoryInput = document.getElementById('category');
    const file = fileInput.files[0];
    const category = categoryInput.value.trim();

    if (file && category) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const content = e.target.result;
            // Check if the file content is text
            if (isTextContent(content)) {
                const lines = content.split('\n');
                files.push({
                    name: file.name,
                    content: lines,
                    category: category
                });
                saveFiles();
                displayFiles();
            } else {
                alert('The file does not contain text content.');
            }
        };
        reader.readAsText(file);
    } else {
        alert('Please select a file and enter a category.');
    }
}

function isTextContent(content) {
    // Simple check to see if the content is text
    return /^[\x00-\x7F]*$/.test(content);
}

function displayFiles() {
    const fileList = document.getElementById('file-list');
    fileList.innerHTML = '';
    files.forEach((file, index) => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <h3>${file.name}</h3>
            <p>Category: ${file.category}</p>
            <button onclick="removeFile(${index})">Remove</button>
        `;
        fileList.appendChild(fileItem);
    });
}

function searchFiles() {
    const searchInput = document.getElementById('search').value.toLowerCase();
    const fileList = document.getElementById('file-list');
    fileList.innerHTML = '';

    if (searchInput === '') {
        // If search input is empty, display only file names and categories
        displayFiles();
    } else {
        // Check if the search input matches any category
        const categoryMatch = files.some(file => file.category.toLowerCase() === searchInput);
        if (categoryMatch) {
            files.forEach(file => {
                if (file.category.toLowerCase() === searchInput) {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-item';
                    fileItem.innerHTML = `<h3>${file.name}</h3><p>Category: ${file.category}</p>`;
                    fileList.appendChild(fileItem);
                }
            });
        } else {
            files.forEach(file => {
                file.content.forEach((line, index) => {
                    if (line.toLowerCase().includes(searchInput) || file.category.toLowerCase().includes(searchInput)) {
                        const fileItem = document.createElement('div');
                        fileItem.className = 'file-item';
                        fileItem.innerHTML = `<h3>${file.category}</h3><p>${file.name}, line ${index + 1}</p><p>${line}</p>`;
                        fileList.appendChild(fileItem);
                    }
                });
            });
        }
    }
}

function removeFile(index) {
    files.splice(index, 1);
    saveFiles();
    displayFiles();
}

function saveFiles() {
    localStorage.setItem('files', JSON.stringify(files));
}