let files = JSON.parse(localStorage.getItem('files')) || [];
let timeline = JSON.parse(localStorage.getItem('timeline')) || [];
let importMode = 'file'; // Default import mode
let filesToImport = [];

document.addEventListener('DOMContentLoaded', () => {
    applySettings();
    displayFiles();
    displayTimeline();
});

function toggleImportMode() {
    const importModeRadios = document.getElementsByName('import-mode');
    const fileInput = document.getElementById('file');

    importModeRadios.forEach(radio => {
        if (radio.checked) {
            importMode = radio.value;
        }
    });

    if (importMode === 'folder') {
        fileInput.setAttribute('webkitdirectory', '');
        fileInput.removeAttribute('multiple');
    } else {
        fileInput.removeAttribute('webkitdirectory');
        fileInput.setAttribute('multiple', '');
    }
}

function prepareImport() {
    const fileInput = document.getElementById('file');
    filesToImport = Array.from(fileInput.files);

    if (filesToImport.length > 0) {
        const fileTagList = document.getElementById('file-tag-list');
        fileTagList.innerHTML = '';

        const folderStructure = buildFolderStructure(filesToImport);

        displayFolderStructure(folderStructure, fileTagList);

        const importSummaryList = document.getElementById('import-summary-list');
        importSummaryList.innerHTML = '';

        filesToImport.forEach(file => {
            const existingFileIndex = files.findIndex(f => f.name === (file.webkitRelativePath || file.name));
            if (existingFileIndex !== -1) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const content = e.target.result;
                    if (files[existingFileIndex].content.join('\n') !== content) {
                        const summaryItem = document.createElement('div');
                        summaryItem.className = 'summary-item';
                        summaryItem.innerHTML = `<p>File: ${file.webkitRelativePath || file.name} will be updated</p>`;
                        importSummaryList.appendChild(summaryItem);
                    }
                };
                reader.readAsText(file);
            } else {
                const summaryItem = document.createElement('div');
                summaryItem.className = 'summary-item';
                summaryItem.innerHTML = `<p>File: ${file.webkitRelativePath || file.name} will be added</p>`;
                importSummaryList.appendChild(summaryItem);
            }
        });

        document.getElementById('tag-modal').style.display = 'block';
    } else {
        alert('Please select a file/folder.');
    }
}

function buildFolderStructure(files) {
    const structure = {};

    files.forEach(file => {
        const pathParts = (file.webkitRelativePath || file.name).split('/');
        let currentLevel = structure;

        pathParts.forEach((part, index) => {
            if (!currentLevel[part]) {
                currentLevel[part] = index === pathParts.length - 1 ? file : {};
            }
            currentLevel = currentLevel[part];
        });
    });

    return structure;
}

function displayFolderStructure(structure, container, path = '') {
    Object.keys(structure).forEach(key => {
        const item = structure[key];
        const fullPath = path ? `${path}/${key}` : key;

        if (item instanceof File) {
            const fileTagItem = document.createElement('div');
            fileTagItem.className = 'file-tag-item';
            fileTagItem.innerHTML = `
                <p>${fullPath}</p>
                <input type="text" id="tag-${fullPath}" placeholder="Enter tag for ${key}">
            `;
            container.appendChild(fileTagItem);
        } else {
            const folderItem = document.createElement('div');
            folderItem.className = 'folder-item';
            folderItem.innerHTML = `<strong>${fullPath}</strong>`;
            container.appendChild(folderItem);

            displayFolderStructure(item, container, fullPath);
        }
    });
}

function closeModal() {
    document.getElementById('tag-modal').style.display = 'none';
}

function confirmImport() {
    filesToImport.forEach(file => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const content = e.target.result;
            if (isTextContent(content)) {
                const lines = content.split('\n');
                const tag = document.getElementById(`tag-${file.webkitRelativePath || file.name}`).value.trim();
                if (tag) {
                    const existingFileIndex = files.findIndex(f => f.name === (file.webkitRelativePath || file.name));
                    if (existingFileIndex !== -1) {
                        if (files[existingFileIndex].content.join('\n') !== content) {
                            updateTimeline('updated', file.webkitRelativePath || file.name);
                            files[existingFileIndex] = {
                                name: file.webkitRelativePath || file.name,
                                content: lines,
                                category: tag
                            };
                        }
                    } else {
                        updateTimeline('added', file.webkitRelativePath || file.name);
                        files.push({
                            name: file.webkitRelativePath || file.name,
                            content: lines,
                            category: tag
                        });
                    }
                    saveFiles();
                    displayFiles();
                }
            } else {
                console.warn(`The file ${file.name} does not contain text content.`);
            }
        };
        reader.readAsText(file);
    });

    closeModal();
}

function isTextContent(content) {
    return /^[\x00-\x7F]*$/.test(content);
}

function displayFiles() {
    const fileList = document.getElementById('file-list');
    fileList.innerHTML = '';

    files.forEach(file => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <h3>${file.name}</h3>
            <p>Category: ${file.category}</p>
            <button onclick="removeFile(${files.indexOf(file)})">Remove</button>
        `;
        fileList.appendChild(fileItem);
    });
}

function searchFiles() {
    const searchInput = document.getElementById('search').value.toLowerCase();
    const fileList = document.getElementById('file-list');
    fileList.innerHTML = '';

    if (searchInput === '') {
        displayFiles();
    } else {
        const categoryMatch = files.some(file => file.category.toLowerCase() === searchInput);
        if (categoryMatch) {
            files.forEach(file => {
                if (file.category.toLowerCase() === searchInput) {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-item';
                    fileItem.innerHTML = `<h3>${file.name}</h3><p>Category: ${file.category}</p>`;
                    fileList.appendChild(fileItem);
                }
            });
        } else {
            files.forEach(file => {
                file.content.forEach((line, index) => {
                    if (line.toLowerCase().includes(searchInput) || file.category.toLowerCase().includes(searchInput)) {
                        const fileItem = document.createElement('div');
                        fileItem.className = 'file-item';
                        fileItem.innerHTML = `<h3>${file.category}</h3><p>${file.name}, line ${index + 1}</p><p>${line}</p>`;
                        fileList.appendChild(fileItem);
                    }
                });
            });
        }
    }
}

function removeFile(index) {
    const removedFile = files.splice(index, 1)[0];
    updateTimeline('removed', removedFile.name);
    saveFiles();
    displayFiles();
}

function saveFiles() {
    localStorage.setItem('files', JSON.stringify(files));
}

function openSettings() {
    document.getElementById('settings-modal').style.display = 'block';
}

function closeSettings() {
    document.getElementById('settings-modal').style.display = 'none';
}

function saveSettings() {
    const bgColor = document.getElementById('bg-color').value;
    const textColor = document.getElementById('text-color').value;
    const textSize = document.getElementById('text-size').value;
    const fontFamily = document.getElementById('font-family').value;

    const settings = {
        bgColor,
        textColor,
        textSize,
        fontFamily
    };

    localStorage.setItem('settings', JSON.stringify(settings));
    applySettings();
    closeSettings();
}

function applySettings() {
    const settings = JSON.parse(localStorage.getItem('settings'));

    if (settings) {
        document.body.style.backgroundColor = settings.bgColor;
        document.body.style.color = settings.textColor;
        document.body.style.fontSize = `${settings.textSize}px`;
        document.body.style.fontFamily = settings.fontFamily;
    }
}

function updateTimeline(action, fileName) {
    const timestamp = new Date().toLocaleString();
    const timelineEntry = {
        action,
        fileName,
        timestamp
    };
    timeline.push(timelineEntry);
    localStorage.setItem('timeline', JSON.stringify(timeline));
    displayTimeline();
}

function displayTimeline() {
    const timelineContainer = document.getElementById('timeline-entries');
    timelineContainer.innerHTML = '';

    timeline.forEach(entry => {
        const timelineItem = document.createElement('div');
        timelineItem.className = 'timeline-entry';
        timelineItem.innerHTML = `
            <p><strong>${entry.action.toUpperCase()}</strong>: ${entry.fileName}</p>
            <p>${entry.timestamp}</p>
        `;
        timelineContainer.appendChild(timelineItem);
    });
}

function clearTimeline() {
    if (confirm('Are you sure you want to clear the timeline?')) {
        timeline = [];
        localStorage.setItem('timeline', JSON.stringify(timeline));
        displayTimeline();
    }
}

function revertTimeline() {
    if (confirm('Are you sure you want to revert the timeline? This will undo all changes.')) {
        timeline.reverse().forEach(entry => {
            if (entry.action === 'added') {
                const fileIndex = files.findIndex(f => f.name === entry.fileName);
                if (fileIndex !== -1) {
                    files.splice(fileIndex, 1);
                }
            } else if (entry.action === 'updated') {
                // Handle reverting updates if necessary
                // This would require storing previous versions of files
            } else if (entry.action === 'removed') {
                // Handle reverting removals if necessary
                // This would require storing removed files
            }
        });
        saveFiles();
        displayFiles();
        timeline = [];
        localStorage.setItem('timeline', JSON.stringify(timeline));
        displayTimeline();
    }
}